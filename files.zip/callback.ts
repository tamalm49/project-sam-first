import { APIGatewayProxyEventV2, APIGatewayProxyStructuredResultV2 } from 'aws-lambda';
import { config } from '../config';
import { msalClient, loginScopes } from '../msalClient';
import { consumePkceTransaction } from '../dynamo/pkceStore';
import { createSession, SessionUser } from '../dynamo/sessionStore';
import { isUserAllowed } from '../dynamo/allowedUsers';
import { buildSessionCookie } from '../cookies';

export async function handler(
  event: APIGatewayProxyEventV2
): Promise<APIGatewayProxyStructuredResultV2> {
  const params = event.queryStringParameters ?? {};
  const { code, state, error, error_description } = params;

  if (error) {
    return { statusCode: 400, body: `Login failed: ${error} - ${error_description ?? ''}` };
  }
  if (!code || !state) {
    return { statusCode: 400, body: 'Missing code or state in callback' };
  }

  const codeVerifier = await consumePkceTransaction(state);
  if (!codeVerifier) {
    return {
      statusCode: 400,
      body: 'Invalid or expired login attempt. Please try signing in again.',
    };
  }

  const result = await msalClient.acquireTokenByCode({
    code,
    scopes: loginScopes,
    redirectUri: config.redirectUri,
    codeVerifier,
  });

  if (!result?.account) {
    return { statusCode: 500, body: 'Login succeeded but no account info was returned' };
  }

  const claims = result.account.idTokenClaims as Record<string, unknown> | undefined;

  const user: SessionUser = {
    oid: result.account.homeAccountId,
    name: result.account.name,
    preferredUsername: result.account.username,
    tenantId: (claims?.tid as string) ?? result.account.tenantId,
  };

  // Authentication (who they are) is done. Authorization (are they allowed
  // in) is separate — checked here, before any session is created.
  const allowed = await isUserAllowed(user.preferredUsername);
  if (!allowed) {
    return {
      statusCode: 403,
      body: `Access denied: ${user.preferredUsername ?? 'this account'} is not on the allowlist for this application.`,
    };
  }

  const sessionId = await createSession(user, result.account.homeAccountId);
  const cookie = buildSessionCookie(sessionId, config.sessionTtlMinutes * 60);

  return {
    statusCode: 302,
    headers: { Location: config.postLoginRedirectUri }, // send them somewhere sensible post-login
    cookies: [cookie],
  };
}
