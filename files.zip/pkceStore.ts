import { PutCommand, GetCommand, DeleteCommand } from '@aws-sdk/lib-dynamodb';
import { ddb } from './client';
import { config } from '../config';

const TRANSACTION_TTL_SECONDS = 5 * 60; // 5 minutes to complete the login round-trip

export async function savePkceTransaction(state: string, codeVerifier: string): Promise<void> {
  const ttl = Math.floor(Date.now() / 1000) + TRANSACTION_TTL_SECONDS;
  await ddb.send(
    new PutCommand({
      TableName: config.pkceTableName,
      Item: { state, codeVerifier, ttl },
    })
  );
}

/**
 * One-time read-and-delete. DynamoDB's own TTL cleanup runs on a best-effort
 * background sweep (usually within 48h, not instantly), so we still check
 * the ttl attribute ourselves rather than relying on it for correctness —
 * TTL here is a cleanup mechanism, not the enforcement point.
 */
export async function consumePkceTransaction(state: string): Promise<string | null> {
  const result = await ddb.send(
    new GetCommand({ TableName: config.pkceTableName, Key: { state } })
  );

  // Delete regardless of outcome — a state value is single-use either way
  await ddb.send(new DeleteCommand({ TableName: config.pkceTableName, Key: { state } }));

  const item = result.Item;
  if (!item) return null;
  if (item.ttl < Math.floor(Date.now() / 1000)) return null;

  return item.codeVerifier as string;
}
