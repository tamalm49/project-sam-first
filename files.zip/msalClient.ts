import { ConfidentialClientApplication, LogLevel } from '@azure/msal-node';
import { azureEndpoints, config } from './config';

// Constructed fresh per invocation is fine — msal-node's client here does no
// network I/O until you call getAuthCodeUrl/acquireTokenByCode. Lambda may
// reuse the execution environment across invocations anyway (this module is
// only evaluated once per warm container).
export const msalClient = new ConfidentialClientApplication({
  auth: {
    clientId: config.clientId,
    authority: azureEndpoints.authority,
    clientSecret: config.clientSecret,
  },
  system: {
    loggerOptions: {
      loggerCallback(level, message, containsPii) {
        if (containsPii) return;
        if (level === LogLevel.Error) console.error('[msal]', message);
      },
      logLevel: LogLevel.Warning,
    },
  },
});

export const loginScopes = ['openid', 'profile', 'offline_access', 'User.Read'];
