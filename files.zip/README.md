# Azure AD login — Lambda + API Gateway (HTTP API) + DynamoDB

Same model as the Express version, ported to serverless: nothing runs on
the client except redirects. Lambda functions run the Authorization Code +
PKCE exchange with `@azure/msal-node`, then mint their own session ID and
set it as an `httpOnly` cookie. DynamoDB replaces the in-memory stores.

PKCE codes themselves are generated with msal-node's own `CryptoProvider`
(`generatePkceCodes()` / `createNewGuid()`) rather than hand-rolled crypto,
since it's the same library already doing the token exchange.

## Architecture

```
API Gateway (HTTP API)
  GET  /auth/login     -> LoginFunction     -> 302 to Azure AD (PKCE stored in PkceTable)
  GET  /auth/callback  -> CallbackFunction  -> exchanges code, checks AllowedUsersTable,
                                                writes SessionsTable, Set-Cookie: sid=...
  GET  /auth/logout    -> LogoutFunction    -> deletes session, redirects to Azure AD logout
  GET  /auth/me        -> MeFunction        -> reads sid cookie, looks up SessionsTable
  GET/POST/DELETE
       /admin/allowed-users -> AdminFunction -> manages AllowedUsersTable (x-admin-secret header)

DynamoDB tables:
  PkceTable          PK: state       TTL: ttl   (~5 min, cleans up abandoned logins)
  SessionsTable      PK: sessionId   TTL: ttl   (sliding expiration via touchSession)
  AllowedUsersTable  PK: email                  (empty table = open access to any tenant user)
```

## Azure Portal setup

Same as the Express version but the redirect URI is your API Gateway's
domain instead of localhost:

1. App registration → Authentication → platform **Web** → redirect URI
   `https://<api-id>.execute-api.<region>.amazonaws.com/auth/callback`
   (get the exact URL from the `ApiUrl` stack output after your first
   deploy, then redeploy — see the chicken-and-egg note below).
2. Certificates & secrets → new client secret.
3. API permissions → `User.Read` (delegated) at minimum.

**Chicken-and-egg note:** the redirect URI depends on the API Gateway URL,
which doesn't exist until you deploy once. Do an initial `sam deploy`, copy
the `ApiUrl` output, register that as the redirect URI in Azure, then you're
set — no further redeploys needed since the URI is derived automatically
in `template.yaml` (`!Sub` against `${HttpApi}...`).

## Deploy

```bash
npm install
sam build
sam deploy --guided
```

You'll be prompted for the stack parameters: `AzureTenantId`, `AzureClientId`,
`AzureClientSecret`, `CookieSecret` (any long random string — used to HMAC-sign
the session cookie), and optionally `AdminSecret` to enable the allowlist API.

`sam local start-api` works for local testing, but Azure AD's redirect will
still go to whatever `AZURE_REDIRECT_URI` resolves to — for local iteration
against the real Azure AD flow you'd need something like `ngrok` pointed at
your local API, since Azure AD needs a real reachable callback URL. `/auth/me`
alone is easy to test locally by manually crafting a signed cookie or calling
`me.ts`'s `resolveSessionUser` in a test.

## Controlling who can access the app

Same two-layer approach as the Express version:

**1. `AllowedUsersTable` (already wired in):** empty table = anyone in the
tenant who authenticates gets a session. Add rows to switch to allowlist
mode:

```bash
# list
curl -H "x-admin-secret: $ADMIN_SECRET" https://<api-id>.execute-api.<region>.amazonaws.com/admin/allowed-users

# add
curl -X POST -H "x-admin-secret: $ADMIN_SECRET" -H "Content-Type: application/json" \
  -d '{"email":"alice@contoso.com"}' https://<api-id>.execute-api.<region>.amazonaws.com/admin/allowed-users

# remove
curl -X DELETE -H "x-admin-secret: $ADMIN_SECRET" \
  https://<api-id>.execute-api.<region>.amazonaws.com/admin/allowed-users/alice@contoso.com
```

**2. Azure AD "Assignment required":** on the app's Enterprise Application →
Properties → Assignment required = Yes, then assign specific users/groups.
Blocks unassigned users at Azure AD itself, before any Lambda runs.

## Protecting additional Lambdas

`handlers/me.ts` exports `resolveSessionUser(cookies)` — import it in any
other Lambda behind this same API and call it first:

```ts
import { resolveSessionUser } from './me';

export async function handler(event: APIGatewayProxyEventV2) {
  const user = await resolveSessionUser(event.cookies);
  if (!user) return { statusCode: 401, body: 'Not signed in' };
  // ... your protected logic, `user` is the SessionUser
}
```

## Before production

- **Client secret**: it's a `NoEcho` CloudFormation parameter here, which
  keeps it out of the console/CLI history but it still ends up as a plain
  Lambda environment variable. For production, store it in Secrets Manager
  instead and fetch it in `msalClient.ts` (cache the fetched value across
  warm invocations), or use a Lambda extension for Secrets Manager caching.
- **DynamoDB TTL cleanup isn't instant** (AWS documents up to 48h for the
  background sweep) — that's why `pkceStore`/`sessionStore` both re-check
  the `ttl` value themselves rather than trusting an expired item to already
  be gone.
- **Cold starts**: `@azure/msal-node`'s confidential client construction is
  cheap (no network call until you actually invoke it), so cold start impact
  here is mostly just Lambda init — `arm64` + `esbuild` minification in the
  template already help.
