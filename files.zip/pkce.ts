import { CryptoProvider } from '@azure/msal-node';

// msal-node's own CryptoProvider implements the RFC 7636 PKCE generation
// (S256 method) and GUID creation, so we don't need to hand-roll base64url
// encoding/hashing ourselves — it's the same library already doing the
// token exchange, so this stays consistent with how MSAL expects the
// verifier/challenge to be shaped.
const cryptoProvider = new CryptoProvider();

export interface PkcePair {
  verifier: string;
  challenge: string;
}

export async function generatePkce(): Promise<PkcePair> {
  const { verifier, challenge } = await cryptoProvider.generatePkceCodes();
  return { verifier, challenge };
}

export function generateState(): string {
  return cryptoProvider.createNewGuid();
}
