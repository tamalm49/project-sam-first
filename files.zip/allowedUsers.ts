import { PutCommand, GetCommand, DeleteCommand, ScanCommand } from '@aws-sdk/lib-dynamodb';
import { ddb } from './client';
import { config } from '../config';

function normalize(email: string): string {
  return email.trim().toLowerCase();
}

/**
 * Table empty = open access (any authenticated tenant user gets in). Add at
 * least one row via the admin API to switch the app into allowlist mode.
 * Flip the `count === 0` branch to `return false` if you'd rather fail
 * closed by default.
 */
export async function isUserAllowed(preferredUsername: string | undefined): Promise<boolean> {
  const scan = await ddb.send(
    new ScanCommand({ TableName: config.allowedUsersTableName, Limit: 1, Select: 'COUNT' })
  );
  if ((scan.Count ?? 0) === 0) return true;

  if (!preferredUsername) return false;

  const result = await ddb.send(
    new GetCommand({
      TableName: config.allowedUsersTableName,
      Key: { email: normalize(preferredUsername) },
    })
  );
  return !!result.Item;
}

export async function addAllowedUser(email: string): Promise<void> {
  await ddb.send(
    new PutCommand({
      TableName: config.allowedUsersTableName,
      Item: { email: normalize(email), addedAt: Date.now() },
    })
  );
}

export async function removeAllowedUser(email: string): Promise<void> {
  await ddb.send(
    new DeleteCommand({
      TableName: config.allowedUsersTableName,
      Key: { email: normalize(email) },
    })
  );
}

export async function listAllowedUsers(): Promise<string[]> {
  const result = await ddb.send(new ScanCommand({ TableName: config.allowedUsersTableName }));
  return (result.Items ?? []).map((item) => item.email as string);
}
