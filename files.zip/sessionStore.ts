import crypto from 'crypto';
import { PutCommand, GetCommand, DeleteCommand, UpdateCommand } from '@aws-sdk/lib-dynamodb';
import { ddb } from './client';
import { config } from '../config';

export interface SessionUser {
  oid: string;
  name?: string;
  preferredUsername?: string;
  tenantId?: string;
}

export interface SessionRecord {
  sessionId: string;
  user: SessionUser;
  homeAccountId: string;
  createdAt: number;
  ttl: number; // epoch seconds — DynamoDB TTL attribute
}

function ttlFromNow(): number {
  return Math.floor(Date.now() / 1000) + config.sessionTtlMinutes * 60;
}

export async function createSession(user: SessionUser, homeAccountId: string): Promise<string> {
  const sessionId = crypto.randomUUID();
  const item: SessionRecord = {
    sessionId,
    user,
    homeAccountId,
    createdAt: Date.now(),
    ttl: ttlFromNow(),
  };

  await ddb.send(new PutCommand({ TableName: config.sessionsTableName, Item: item }));
  return sessionId;
}

export async function getSession(sessionId: string): Promise<SessionRecord | null> {
  const result = await ddb.send(
    new GetCommand({ TableName: config.sessionsTableName, Key: { sessionId } })
  );
  const item = result.Item as SessionRecord | undefined;
  if (!item) return null;

  if (item.ttl < Math.floor(Date.now() / 1000)) return null; // don't rely solely on DynamoDB's own TTL sweep timing
  return item;
}

export async function touchSession(sessionId: string): Promise<void> {
  await ddb.send(
    new UpdateCommand({
      TableName: config.sessionsTableName,
      Key: { sessionId },
      UpdateExpression: 'SET #ttl = :ttl',
      ExpressionAttributeNames: { '#ttl': 'ttl' },
      ExpressionAttributeValues: { ':ttl': ttlFromNow() },
    })
  );
}

export async function destroySession(sessionId: string): Promise<void> {
  await ddb.send(new DeleteCommand({ TableName: config.sessionsTableName, Key: { sessionId } }));
}
