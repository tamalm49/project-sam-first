import { APIGatewayProxyEventV2, APIGatewayProxyStructuredResultV2 } from 'aws-lambda';
import { azureEndpoints, config } from '../config';
import { destroySession } from '../dynamo/sessionStore';
import { readSessionIdFromCookies, buildClearCookie } from '../cookies';

export async function handler(
  event: APIGatewayProxyEventV2
): Promise<APIGatewayProxyStructuredResultV2> {
  const sessionId = readSessionIdFromCookies(event.cookies);
  if (sessionId) {
    await destroySession(sessionId);
  }

  const logoutUrl = `${azureEndpoints.logoutUrl}?post_logout_redirect_uri=${encodeURIComponent(
    config.postLogoutRedirectUri
  )}`;

  return {
    statusCode: 302,
    headers: { Location: logoutUrl },
    cookies: [buildClearCookie()],
  };
}
