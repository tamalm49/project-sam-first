import { APIGatewayProxyEventV2, APIGatewayProxyStructuredResultV2 } from 'aws-lambda';
import { config } from '../config';
import { addAllowedUser, removeAllowedUser, listAllowedUsers } from '../dynamo/allowedUsers';

function json(statusCode: number, body: unknown): APIGatewayProxyStructuredResultV2 {
  return { statusCode, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) };
}

export async function handler(
  event: APIGatewayProxyEventV2
): Promise<APIGatewayProxyStructuredResultV2> {
  if (!config.adminSecret) {
    return json(503, { error: 'Admin API disabled: ADMIN_SECRET is not set' });
  }

  const provided = event.headers?.['x-admin-secret'] ?? event.headers?.['X-Admin-Secret'];
  if (provided !== config.adminSecret) {
    return json(401, { error: 'Invalid admin secret' });
  }

  const method = event.requestContext.http.method;

  if (method === 'GET') {
    return json(200, { users: await listAllowedUsers() });
  }

  if (method === 'POST') {
    const body = event.body ? JSON.parse(event.isBase64Encoded ? atob(event.body) : event.body) : {};
    if (!body.email || typeof body.email !== 'string') {
      return json(400, { error: 'Body must include "email"' });
    }
    await addAllowedUser(body.email);
    return json(201, { users: await listAllowedUsers() });
  }

  if (method === 'DELETE') {
    const email = event.pathParameters?.email;
    if (!email) {
      return json(400, { error: 'Missing email path parameter' });
    }
    await removeAllowedUser(decodeURIComponent(email));
    return json(200, { users: await listAllowedUsers() });
  }

  return json(405, { error: 'Method not allowed' });
}
