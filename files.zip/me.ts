import { APIGatewayProxyEventV2, APIGatewayProxyStructuredResultV2 } from 'aws-lambda';
import { getSession, touchSession, SessionUser } from '../dynamo/sessionStore';
import { readSessionIdFromCookies } from '../cookies';

/**
 * Reusable in any other Lambda that needs to be "protected" — call this
 * first thing in the handler and bail out on null the same way this
 * function does for /auth/me.
 */
export async function resolveSessionUser(
  cookies: string[] | undefined
): Promise<SessionUser | null> {
  const sessionId = readSessionIdFromCookies(cookies);
  if (!sessionId) return null;

  const session = await getSession(sessionId);
  if (!session) return null;

  await touchSession(sessionId); // sliding expiration
  return session.user;
}

export async function handler(
  event: APIGatewayProxyEventV2
): Promise<APIGatewayProxyStructuredResultV2> {
  const user = await resolveSessionUser(event.cookies);

  if (!user) {
    return { statusCode: 401, body: JSON.stringify({ error: 'Not signed in' }) };
  }

  return {
    statusCode: 200,
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ user }),
  };
}
