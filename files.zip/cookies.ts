import crypto from 'crypto';
import { config } from './config';

export const SESSION_COOKIE_NAME = 'sid';

function base64UrlEncode(buffer: Buffer): string {
  return buffer.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

function sign(value: string): string {
  const hmac = crypto.createHmac('sha256', config.cookieSecret).update(value).digest();
  return base64UrlEncode(hmac);
}

/** Produces "sid=<sessionId>.<signature>; HttpOnly; ..." for a Set-Cookie / API Gateway `cookies` entry */
export function buildSessionCookie(sessionId: string, maxAgeSeconds: number): string {
  const signature = sign(sessionId);
  const value = `${sessionId}.${signature}`;
  const attrs = [
    `${SESSION_COOKIE_NAME}=${value}`,
    'Path=/',
    'HttpOnly',
    `Max-Age=${maxAgeSeconds}`,
    'SameSite=Lax',
  ];
  if (config.cookieSecure) attrs.push('Secure');
  return attrs.join('; ');
}

export function buildClearCookie(): string {
  const attrs = [`${SESSION_COOKIE_NAME}=`, 'Path=/', 'HttpOnly', 'Max-Age=0', 'SameSite=Lax'];
  if (config.cookieSecure) attrs.push('Secure');
  return attrs.join('; ');
}

/**
 * API Gateway HTTP API (payload format 2.0) hands incoming cookies to you
 * pre-split in `event.cookies` (one array entry per cookie), unlike the
 * classic `Cookie: a=1; b=2` header you'd parse yourself elsewhere.
 */
export function readSessionIdFromCookies(cookies: string[] | undefined): string | null {
  if (!cookies) return null;

  for (const cookie of cookies) {
    const [name, value] = cookie.split('=');
    if (name === SESSION_COOKIE_NAME && value) {
      const [sessionId, signature] = value.split('.');
      if (!sessionId || !signature) return null;
      // Constant-time compare so this can't be timing-attacked
      const expected = sign(sessionId);
      const a = Buffer.from(signature);
      const b = Buffer.from(expected);
      if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
      return sessionId;
    }
  }
  return null;
}
