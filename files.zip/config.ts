function required(name: string): string {
  const value = process.env[name];
  if (!value) throw new Error(`Missing required env var: ${name}`);
  return value;
}

export const config = {
  tenantId: required('AZURE_TENANT_ID'),
  clientId: required('AZURE_CLIENT_ID'),
  clientSecret: required('AZURE_CLIENT_SECRET'),
  redirectUri: required('AZURE_REDIRECT_URI'),
  postLoginRedirectUri: process.env.POST_LOGIN_REDIRECT_URI ?? 'https://example.com/dashboard',
  postLogoutRedirectUri: process.env.POST_LOGOUT_REDIRECT_URI ?? 'https://example.com/',
  cookieSecret: required('COOKIE_SECRET'),
  cookieSecure: process.env.COOKIE_SECURE !== 'false', // default true — this is API Gateway, always HTTPS
  sessionTtlMinutes: Number(process.env.SESSION_TTL_MINUTES ?? 60),
  adminSecret: process.env.ADMIN_SECRET ?? '',
  pkceTableName: required('PKCE_TABLE_NAME'),
  sessionsTableName: required('SESSIONS_TABLE_NAME'),
  allowedUsersTableName: required('ALLOWED_USERS_TABLE_NAME'),
};

export const azureEndpoints = {
  authority: `https://login.microsoftonline.com/${config.tenantId}`,
  logoutUrl: `https://login.microsoftonline.com/${config.tenantId}/oauth2/v2.0/logout`,
};
