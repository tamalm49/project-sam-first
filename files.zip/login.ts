import { APIGatewayProxyEventV2, APIGatewayProxyStructuredResultV2 } from 'aws-lambda';
import { config } from '../config';
import { msalClient, loginScopes } from '../msalClient';
import { generatePkce, generateState } from '../pkce';
import { savePkceTransaction } from '../dynamo/pkceStore';

export async function handler(
  _event: APIGatewayProxyEventV2
): Promise<APIGatewayProxyStructuredResultV2> {
  const { verifier, challenge } = await generatePkce();
  const state = generateState();

  await savePkceTransaction(state, verifier);

  const authUrl = await msalClient.getAuthCodeUrl({
    scopes: loginScopes,
    redirectUri: config.redirectUri,
    state,
    codeChallenge: challenge,
    codeChallengeMethod: 'S256',
  });

  return {
    statusCode: 302,
    headers: { Location: authUrl },
  };
}
